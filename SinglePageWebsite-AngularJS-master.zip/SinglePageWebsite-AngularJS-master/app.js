(function () {
    'use strict';

    angular.modulue('myFirstApp',[])
        .controller('myFirstController', function () {
            
        });
})